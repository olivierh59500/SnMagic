var app = angular.module('cam', ['ngMaterial']);

var dev = { headers: {
	"authorization": "Bearer 8c75de196880a07649ecd4df6f3d93e80ee75e32fed94f74fb29aa0a0dcf0a48",
						 }
			  };
  
var  prodsupp = { headers : {
	"authorization": "Bearer 647d45af904421c6af2c37f6c01308fd3b0ea4b3295cca46543dd92495330544",
							}
			   };
var  stage = { headers : {
	"authorization": "Bearer 8c75de196880a07649ecd4df6f3d93e80ee75e32fed94f74fb29aa0a0dcf0a48",
							}
			   };
var  testspace = { headers : {
	"authorization": "Bearer a0d1a649b5f24a3a854239ea6ebd725b793feeca6c6e5fb2283936b4fff7e538",
							}
			   };
//Controller starts here 
app.controller ('layoutController', ['$scope', '$http', '$q', '$timeout', '$window', function($scope, $http, $q, $timeout, $window) {
//Variable Declaration
$scope.spaces = [
	{value : "0", space : "--Select--"},
	{value : "8ox2awauu9jv", space : "Dev"},
	{value : "5dbvnk7okbss", space : "Stage"},
	{value : "acgwxy3nh1xr", space : "ProdSupp"},
	{value : "y5d468jjhk6r", space : "TestSpace"}
				];
	$scope.selectedfiles = {};
	$scope.destFiles = [];
	$scope.selectedSource=$scope.spaces[0];
	$scope.selectedDest=$scope.spaces[0];
	$scope.filelocale=[];
	$scope.sourceassetinfo =[];
	$scope.newfilesinfo=[];
	$scope.sourcepath =[];
	var promises = [];
	var migratepromise =[];
	var processpromise =[];
	$scope.sourceconfig; 
	$scope.desconfig;
	$scope.checksuccessful=[];
	$scope.checkerrorcase=[];
	//initialized with 0
	$scope.samlversion=1;
//Fetch all published asset of a selected Sorce Space
$scope.changedValue = function(srcitem)
{	//clear status if any
	if($scope.checksuccessful.length > 0)
		$scope.checksuccessful.splice(0);

	if($scope.checkerrorcase.length > 0)
		$scope.checkerrorcase.splice(0);

	$scope.srcitem = srcitem;	

	if($scope.srcitem.value == "0") {
		$scope.names = [];
		$scope.destFiles = [];
		return false;
	}
	if($scope.srcitem.space == "Dev")
		$scope.sourceconfig = dev;
	else if ($scope.srcitem.space == "ProdSupp")
		$scope.sourceconfig = prodsupp;
	else if ($scope.srcitem.space == "Stage")
		$scope.sourceconfig = stage;
	else if ($scope.srcitem.space == "TestSpace")
		$scope.sourceconfig = testspace;

	$http.get("https://api.contentful.com/spaces/" + srcitem.value + "/public/assets", $scope.sourceconfig)
		.success(function(response) {
			$scope.names = response.items;	
	});
} //end of changedvalue  

//Fetch dest assets
$scope.getDestAssets = function(destitem)
{	//clear status if any
	if($scope.checksuccessful.length >0)
	$scope.checksuccessful.splice(0);
	if($scope.checkerrorcase.length >0)
	$scope.checkerrorcase.splice(0);

	$scope.destitem = destitem;

	if($scope.destitem.value == "0") {
		$scope.selectedfiles = {};
	    $scope.destFiles = [];
	    return false;
	}

	if($scope.destitem.space == "Dev")
		$scope.destconfig=dev;
	else if ($scope.destitem.space == "ProdSupp")
		$scope.destconfig=prodsupp;
	else if ($scope.destitem.space == "Stage")
		$scope.destconfig=stage;
	else if ($scope.destitem.space == "TestSpace")
		$scope.destconfig=testspace;

	$http.get("https://api.contentful.com/spaces/"+ destitem.value + "/assets", $scope.destconfig)
		.success(function(response) {
			$scope.destFiles = response.items;
		});
} // End of getDestAssets



function getDestFiles(fileName, locale, spaceID){
	console.log(locale);
			for(var asset in $scope.destFiles){
			
				if($scope.destFiles[asset].sys.id == fileName){
					return true;
				}
			
			}
		}

//Migrate assets from source to Destination
$scope.migratecontent = function(item)
{
 
	$scope.selectedvalues = item;
	//loop for traversing selected items 
	angular.forEach($scope.selectedvalues, function(key, path){
	//if key is true as in asset is selected
		 if(key==true)
		{ 	
			$scope.path=path;
			var tmp = path.split("/");
			$scope.asset=tmp.pop();
			$scope.locale=path.split('//')[0].substring(0,5);
			$scope.contentType=path.split('//')[0].substring(5);
			//check if selected is ever moved to dest or not 
			if(getDestFiles($scope.asset, $scope.locale, $scope.destitem.value)==true)
			{
			console.log("found case");
			$scope.sourcepath.push({
				path : path.split('//')[1],
				asset: $scope.asset,
				locale : $scope.locale,
				contentType :$scope.contentType,
				processedsource : false
			});
			
			 promises.push($http.get("https://api.contentful.com/spaces/"+$scope.destitem.value+"/assets/"+$scope.asset+" ",$scope.destconfig));
			}
			//if the asset is moving for the first time to destination 
			else
			{
			console.log("not found case");
			
			var config3 ={ headers :{
					"Authorization": $scope.destconfig.headers.authorization ,
					"Content-Type" : "application/vnd.contentful.management.v1+json",
					"X-Contentful-Version" : 0

											}

								};//END header config

				//create a json body 
				$scope.header3=config3;
				var jsonbody={
					"fields": {
						"title": {
							
						},
						"file": {
							
						}
					}
				};
				
				
				
				
				var incrementor=0;
				if($scope.newfilesinfo.length==0 || $scope.newfilesinfo[incrementor].asset!=$scope.asset)
				{
				$scope.jsonnewfile=jsonbody;
				$scope.jsonnewfile.fields.title[$scope.locale] = $scope.asset ;
				
				$scope.jsonnewfile.fields.file[$scope.locale] ={"contentType" :$scope.contentType,"fileName": $scope.asset,"upload": "https:"+"//"+$scope.path.split('//')[1]  }
				$scope.newfilesinfo.push({
						contentType : $scope.contentType,
						asset : $scope.asset,
						jsonbody :$scope.jsonnewfile,
						header : $scope.header3,
						locale : $scope.locale,
						processedfile :false
							  });
							  incrementor++;
				}			  
				else
				{
				$scope.jsonnewfile.fields.title[$scope.locale] = $scope.asset ;
				
				$scope.jsonnewfile.fields.file[$scope.locale] ={"contentType" :$scope.contentType,"fileName": $scope.asset,"upload": "https:"+"//"+$scope.path.split('//')[1]  }
				
				
				config3 ={ headers :{
					"Authorization": $scope.destconfig.headers.authorization ,
					"Content-Type" : "application/vnd.contentful.management.v1+json",
					"X-Contentful-Version" : $scope.samlversion

											}

								};//END header config
				$scope.samlversion=$scope.samlversion+1;
							  $scope.newfilesinfo.push({
						contentType : $scope.contentType,
						asset : $scope.asset,
						jsonbody :$scope.jsonnewfile,
						header : config3,
						locale : $scope.locale,
						processedfile :false
							  });
							  incrementor++;
				}
							 for(var prop in $scope.newfilesinfo) {
							if($scope.newfilesinfo[prop].processedfile==false)
								{
				//End creating a json body 
				$http.put("https://api.contentful.com/spaces/"+$scope.destitem.value+"/assets/"+$scope.newfilesinfo[prop].asset+"",$scope.newfilesinfo[prop].jsonbody,$scope.newfilesinfo[prop].header)
					.success(function(response,processstatus,headers,config){
					console.log("e")
					$scope.processstatus=processstatus;
					console.log($scope.processstatus)
					$scope.status=config;
					
						$scope.checksuccessful.push({
						asset: $scope.status.url.split("/")[6],
						locale: $scope.status.url.split("/")[8]
						
						});
					// START - process an asset
					$scope.newfilesinfo[prop].header.headers["X-Contentful-Version"]= incrementor;//$scope.newfilesinfo[prop].header.headers["X-Contentful-Version"]+3;
					$http.put("https://api.contentful.com/spaces/"+$scope.destitem.value+"/assets/"+$scope.newfilesinfo[prop].asset+"/files/"+$scope.newfilesinfo[prop].locale+"/process",$scope.newfilesinfo[prop].jsonbody,$scope.newfilesinfo[prop].header)
						.success(function(response,status,header,config){
						incrementor++;
						$scope.processed=response;
						
						
						});// END - process an asset

					}).error(function(response,status,header,config){
					
						$scope.errorstatus=config;
						$scope.checkerrorcase.push({
						asset: $scope.errorstatus.url.split("/")[6],
						locale: $scope.errorstatus.url.split("/")[8]
						
						});
						}); 
					 $scope.newfilesinfo[prop].processedfile="true";
								}//end of if 
					}//end of for loop
			}//end of else case 
		}//end of key=true if 

}                                                     ); //end of traversal loop
    $q.all(promises).then(function(response){
	console.log(response);
	for (var i=0,len = response.length;i<len;++i){
	console.log(response[i].data);
	$scope.response=response[i].data;
	//for(var prop1 in $scope.sourcepath) { 
		console.log("inside loop")
		//console.log(response[i].data.fields.file[$scope.sourcepath[prop1].locale].upload);
		if($scope.sourcepath[i].asset==response[i].data.sys.id)
		{
		var config3 ={ headers :{
		"Authorization": $scope.destconfig.headers.authorization ,
		"Content-Type" : "application/vnd.contentful.management.v1+json",
		"X-Contentful-Version" : response[i].data.sys.version

								}
					};//END header config
		$scope.header=config3;
		// var jsonbody={
          //  "fields":{
		//		"title": {
					
		//		},
		///		"file": {
					
		//		}
		//	}
      // 	}; //end creating a json body 
		$scope.json=response[i].data;
		
			$scope.json.fields.title[$scope.locale] = $scope.sourcepath[i].asset;
			
			$scope.json.fields.file[$scope.locale] ={"contentType" :$scope.sourcepath[i].contentType ,"fileName": $scope.sourcepath[i].asset,"upload": "https:"+"//"+$scope.sourcepath[i].path }
	
	$scope.sourceassetinfo.push({
					version : response[i].data.sys.version,
					contenttype : $scope.sourcepath[i].contentType,
					asset : $scope.sourcepath[i].asset,
					uploadpath : $scope.sourcepath[i].path,
					header : $scope.header,
					jsonbody : $scope.json,
					locale : $scope.sourcepath[i].locale,
					processed :false
	});
	}
	//}
		
	
	}

	

	}).catch(function(error){
	$scope.error=error;
	console.log('there was an error -'+error.status);
	
	}).then(function(){
	console.log("inside nested then");
	for( var val in $scope.sourceassetinfo)
	{
//	if ($scope.checkfordup.indexOf($scope.sourceassetinfo[1].asset)==-1) 
	//{
	console.log("step2");
	$http.put("https://api.contentful.com/spaces/"+$scope.destitem.value+"/assets/"+$scope.sourceassetinfo[val].asset+"", $scope.sourceassetinfo[val].jsonbody,$scope.sourceassetinfo[val].header)
	.success(function(response,status, header,config){
	console.log("success found acase migrate");
	//console.log(response)
	//$scope.res=response[val].data;
	//$scope.endstatus= "Asset "+$scope.sourceassetinfo[i].asset +" of locale "+ $scope.sourceassetinfo[i].locale +
	 $http.put("https://api.contentful.com/spaces/"+$scope.destitem.value+"/assets/"+$scope.sourceassetinfo[val].asset+"/files/"+$scope.sourceassetinfo[val].locale+"/process","",$scope.sourceassetinfo[val].header)
							.success(function(response,status,header,config){
						
		console.log("success process");
	
		});
		$scope.status=config;
		$scope.checksuccessful.push({
		asset: $scope.status.url.split("/")[6],
		locale: $scope.status.url.split("/")[8]
		
		});
	
	}).error(function(response,status,headers,config){
	$scope.errorstatus=config;
	if($scope.errorstatus.length >0)
	{
		$scope.checkerrorcase.push({
		asset: $scope.errorstatus.url.split("/")[6],
		locale: $scope.errorstatus.url.split("/")[8]
		
		});
	}
	else{
	$scope.checkerrorcase.push({
		asset: "Unprocessable entry",
		locale: ""
		
		});
	}
	});
	//}
	}
	
	
	});
	//reset the dropdown to default values
	document.getElementById("ddlSrcSpace").selectedIndex = 0;
	//$scope.selectedSource = $scope.spaces[0];
	document.getElementById("ddlDestSpace").selectedIndex = 0;
	$scope.selectedfiles = {};
	$scope.names={};
	//$scope.sourcepath=[];
	//$scope.newfilesinfo=[];
	//$scope.sourceassetinfo=[];
	
} //end of migrate function

}]); //end of controller